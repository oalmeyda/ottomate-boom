from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query

from ottomate_core import auth
from ottomate_core import db as db_module
from ottomate_core.auth import User, dev_mode_enabled, get_current_user
from ottomate_core.config import USERS_COLLECTION
from ottomate_core.deps import is_game_admin, is_super_admin, service_role_keys
from ottomate_core.models import (
    AdminProxiesUpdate,
    EmailCheckRequest,
    PreferencesUpdate,
    ProfileUpdate,
    ProxyAddRequest,
    UserCreateRequest,
    UserRoleUpdate,
)


def resolve_user_proxies(db, user_data: dict, current_user_email: str):
    """Resolves authorized proxies for the user and users that this user can act as proxy for."""
    norm_current = current_user_email.strip().lower()
    raw_proxies = [p.strip().lower() for p in user_data.get("proxies", []) if isinstance(p, str)]

    proxies_detailed = []
    for p_email in raw_proxies:
        p_snap = db.collection(USERS_COLLECTION).document(db_module.user_key(p_email)).get()
        p_data = p_snap.to_dict() if p_snap.exists and p_snap.to_dict() else {}
        p_name = p_data.get("display_name") or p_email
        proxies_detailed.append({
            "email": p_email,
            "display_name": db_module.format_short_name(p_name),
        })

    proxy_for_detailed = []
    try:
        query = db.collection(USERS_COLLECTION).where("proxies", "array_contains", norm_current)
        for snap in query.stream():
            if snap.exists and snap.to_dict():
                sd = snap.to_dict()
                t_email = (sd.get("email") or "").strip().lower()
                if t_email and t_email != norm_current:
                    proxy_for_detailed.append({
                        "email": sd.get("email") or t_email,
                        "display_name": db_module.format_short_name(sd.get("display_name") or t_email),
                    })
    except Exception:
        for snap in db.collection(USERS_COLLECTION).stream():
            if snap.exists and snap.to_dict():
                sd = snap.to_dict()
                sd_proxies = [p.strip().lower() for p in sd.get("proxies", []) if isinstance(p, str)]
                if norm_current in sd_proxies:
                    t_email = (sd.get("email") or "").strip().lower()
                    if t_email and t_email != norm_current:
                        proxy_for_detailed.append({
                            "email": sd.get("email") or t_email,
                            "display_name": db_module.format_short_name(sd.get("display_name") or t_email),
                        })

    return proxies_detailed, proxy_for_detailed


def create_users_router(service_name: str) -> APIRouter:
    router = APIRouter(tags=["Users"])

    @router.get("/api/me")
    def get_me(user: User = Depends(get_current_user)):
        db = db_module.users_database()
        user_is_super = is_super_admin(user)
        user_is_game = is_game_admin(user, service_name)

        # Check if service is currently undergoing maintenance
        s_id = service_name.removeprefix("ottomate-")
        service_under_maintenance = False
        maintenance_note = None
        if s_id != "hub":
            try:
                service_snap = db.collection("services").document(s_id).get()
                if service_snap.exists:
                    s_data = service_snap.to_dict() or {}
                    if s_data.get("is_denylisted"):
                        service_under_maintenance = True
                        maintenance_note = s_data.get("admin_note") or "Service is currently undergoing scheduled maintenance. Please check back later."
                        if not (user_is_super or user_is_game):
                            raise HTTPException(
                                status_code=503,
                                detail=maintenance_note,
                            )
            except HTTPException:
                raise
            except Exception as exc:
                import logging
                logging.getLogger(__name__).warning("Failed to check maintenance for %s: %s", s_id, exc)

        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(user.email))
        user_doc = user_ref.get()
        now = datetime.now(timezone.utc)
        user_data = user_doc.to_dict() if user_doc.exists and user_doc.to_dict() else {}

        # Enforce admin-only user onboarding:
        # If user record doesn't exist and user is not a super admin, reject access (unless in dev mode).
        if not user_doc.exists and not user_is_super and not dev_mode_enabled():
            raise HTTPException(
                status_code=403,
                detail="Registration is restricted. New users must be added by an administrator.",
            )

        configured_name = user_data.get("display_name")
        configured_nick = user_data.get("nickname") or configured_name
        last_log_at = user_data.get("last_log_at")
        prev_login = user_data.get("last_login_at") or now

        # Update last_login_at
        user_ref.set(
            {
                "email": user.email,
                "last_login_at": now,
                "updated_at": now,
            },
            merge=True,
        )

        user_roles = user_data.get("roles", {})
        proxies_detailed, proxy_for_detailed = resolve_user_proxies(db, user_data, user.email)

        return {
            "email": user.email,
            "display_name": configured_name or user.display_name,
            "nickname": configured_nick,
            "has_nickname": bool(configured_nick),
            "can_create_challenge": user_is_game,
            "can_create_game": user_is_game,
            "is_super_admin": user_is_super,
            "is_game_admin": user_is_game,
            "roles": user_roles,
            "preferences": user_data.get("preferences", {}),
            "proxies": proxies_detailed,
            "proxy_for": proxy_for_detailed,
            "last_login_at": prev_login.isoformat() if hasattr(prev_login, "isoformat") else str(prev_login),
            "last_log_at": last_log_at.isoformat() if hasattr(last_log_at, "isoformat") else (str(last_log_at) if last_log_at else None),
            "is_under_maintenance": service_under_maintenance,
            "maintenance_note": maintenance_note,
        }

    @router.get("/api/me/proxies")
    def get_my_proxies(user: User = Depends(get_current_user)):
        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(user.email))
        user_doc = user_ref.get()
        user_data = user_doc.to_dict() if user_doc.exists and user_doc.to_dict() else {}
        proxies, proxy_for = resolve_user_proxies(db, user_data, user.email)
        return {"proxies": proxies, "proxy_for": proxy_for}

    @router.post("/api/me/proxies", status_code=201)
    def add_my_proxy(payload: ProxyAddRequest, user: User = Depends(get_current_user)):
        target_email = db_module.normalize_email(payload.email)
        if target_email == user.email.strip().lower():
            raise HTTPException(status_code=400, detail="You cannot designate yourself as a proxy.")

        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(user.email))
        now = datetime.now(timezone.utc)
        user_doc = user_ref.get()
        user_data = user_doc.to_dict() if user_doc.exists and user_doc.to_dict() else {}

        current_proxies = [p.strip().lower() for p in user_data.get("proxies", []) if isinstance(p, str)]
        if target_email not in current_proxies:
            current_proxies.append(target_email)

        user_ref.set(
            {
                "email": user.email,
                "proxies": current_proxies,
                "updated_at": now,
            },
            merge=True,
        )
        user_data["proxies"] = current_proxies
        proxies, proxy_for = resolve_user_proxies(db, user_data, user.email)
        return {"proxies": proxies, "proxy_for": proxy_for}

    @router.delete("/api/me/proxies/{target_email}")
    def remove_my_proxy(target_email: str, user: User = Depends(get_current_user)):
        norm_target = db_module.normalize_email(target_email)
        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(user.email))
        now = datetime.now(timezone.utc)
        user_doc = user_ref.get()
        user_data = user_doc.to_dict() if user_doc.exists and user_doc.to_dict() else {}

        current_proxies = [p.strip().lower() for p in user_data.get("proxies", []) if isinstance(p, str)]
        current_proxies = [p for p in current_proxies if p != norm_target]

        user_ref.set(
            {
                "email": user.email,
                "proxies": current_proxies,
                "updated_at": now,
            },
            merge=True,
        )
        user_data["proxies"] = current_proxies
        proxies, proxy_for = resolve_user_proxies(db, user_data, user.email)
        return {"proxies": proxies, "proxy_for": proxy_for}

    @router.get("/api/users/{target_email}/proxies")
    def get_user_proxies(target_email: str, user: User = Depends(get_current_user)):
        norm_target = db_module.normalize_email(target_email)
        if norm_target != user.email.strip().lower() and not is_game_admin(user, service_name):
            raise HTTPException(
                status_code=403,
                detail="Only Game Admins or Super Admins can view other users' proxies.",
            )
        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(norm_target))
        user_doc = user_ref.get()
        user_data = user_doc.to_dict() if user_doc.exists and user_doc.to_dict() else {}
        proxies, proxy_for = resolve_user_proxies(db, user_data, norm_target)
        display_name = user_data.get("display_name") or norm_target
        return {
            "email": norm_target,
            "display_name": db_module.format_short_name(display_name),
            "proxies": proxies,
            "proxy_for": proxy_for,
        }

    @router.post("/api/users/{target_email}/proxies", status_code=201)
    def add_user_proxy(
        target_email: str,
        payload: ProxyAddRequest,
        user: User = Depends(get_current_user),
    ):
        norm_target = db_module.normalize_email(target_email)
        if norm_target != user.email.strip().lower() and not is_game_admin(user, service_name):
            raise HTTPException(
                status_code=403,
                detail="Only Game Admins or Super Admins can manage other users' proxies.",
            )
        proxy_email = db_module.normalize_email(payload.email)
        if proxy_email == norm_target:
            raise HTTPException(status_code=400, detail="A user cannot be designated as their own proxy.")

        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(norm_target))
        now = datetime.now(timezone.utc)
        user_doc = user_ref.get()
        user_data = user_doc.to_dict() if user_doc.exists and user_doc.to_dict() else {}

        current_proxies = [p.strip().lower() for p in user_data.get("proxies", []) if isinstance(p, str)]
        if proxy_email not in current_proxies:
            current_proxies.append(proxy_email)

        user_ref.set(
            {
                "email": norm_target,
                "proxies": current_proxies,
                "updated_at": now,
            },
            merge=True,
        )
        user_data["proxies"] = current_proxies
        proxies, proxy_for = resolve_user_proxies(db, user_data, norm_target)
        display_name = user_data.get("display_name") or norm_target
        return {
            "email": norm_target,
            "display_name": db_module.format_short_name(display_name),
            "proxies": proxies,
            "proxy_for": proxy_for,
        }

    @router.delete("/api/users/{target_email}/proxies/{proxy_email}")
    def remove_user_proxy(
        target_email: str,
        proxy_email: str,
        user: User = Depends(get_current_user),
    ):
        norm_target = db_module.normalize_email(target_email)
        norm_proxy = db_module.normalize_email(proxy_email)
        if norm_target != user.email.strip().lower() and not is_game_admin(user, service_name):
            raise HTTPException(
                status_code=403,
                detail="Only Game Admins or Super Admins can manage other users' proxies.",
            )
        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(norm_target))
        now = datetime.now(timezone.utc)
        user_doc = user_ref.get()
        user_data = user_doc.to_dict() if user_doc.exists and user_doc.to_dict() else {}

        current_proxies = [p.strip().lower() for p in user_data.get("proxies", []) if isinstance(p, str)]
        current_proxies = [p for p in current_proxies if p != norm_proxy]

        user_ref.set(
            {
                "email": norm_target,
                "proxies": current_proxies,
                "updated_at": now,
            },
            merge=True,
        )
        user_data["proxies"] = current_proxies
        proxies, proxy_for = resolve_user_proxies(db, user_data, norm_target)
        display_name = user_data.get("display_name") or norm_target
        return {
            "email": norm_target,
            "display_name": db_module.format_short_name(display_name),
            "proxies": proxies,
            "proxy_for": proxy_for,
        }

    @router.put("/api/users/{target_email}/proxies")
    def set_user_proxies(
        target_email: str,
        payload: AdminProxiesUpdate,
        user: User = Depends(get_current_user),
    ):
        norm_target = db_module.normalize_email(target_email)
        if norm_target != user.email.strip().lower() and not is_game_admin(user, service_name):
            raise HTTPException(
                status_code=403,
                detail="Only Game Admins or Super Admins can manage user proxies.",
            )
        clean_proxies = list({db_module.normalize_email(p) for p in payload.proxies if db_module.normalize_email(p) != norm_target})
        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(norm_target))
        now = datetime.now(timezone.utc)
        user_ref.set(
            {
                "email": norm_target,
                "proxies": clean_proxies,
                "updated_at": now,
            },
            merge=True,
        )
        user_doc = user_ref.get()
        user_data = user_doc.to_dict() if user_doc.exists and user_doc.to_dict() else {}
        proxies, proxy_for = resolve_user_proxies(db, user_data, norm_target)
        return {
            "email": norm_target,
            "proxies": proxies,
            "proxy_for": proxy_for,
        }


    @router.put("/api/me/profile")
    def update_profile(payload: ProfileUpdate, user: User = Depends(get_current_user)):
        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(user.email))
        now = datetime.now(timezone.utc)
        user_doc = user_ref.get()

        if not user_doc.exists and not is_super_admin(user):
            raise HTTPException(
                status_code=403,
                detail="Registration is restricted. New users must be added by an administrator.",
            )

        user_data = user_doc.to_dict() if user_doc.exists and user_doc.to_dict() else {}

        update_payload = {
            "email": user.email,
            "updated_at": now,
        }
        if payload.display_name is not None:
            update_payload["display_name"] = payload.display_name
            update_payload["nickname"] = payload.display_name

        current_prefs = dict(user_data.get("preferences", {}))
        if payload.preferences is not None:
            pref_data = payload.preferences if isinstance(payload.preferences, dict) else payload.preferences.model_dump(exclude_unset=True)
            current_prefs.update({k: v for k, v in pref_data.items() if v is not None})
            update_payload["preferences"] = current_prefs

        if not user_doc.exists:
            update_payload["created_at"] = now
            update_payload["last_login_at"] = now

        user_ref.set(update_payload, merge=True)

        return {
            "email": user.email,
            "display_name": payload.display_name or user_data.get("display_name") or user.display_name,
            "nickname": payload.display_name or user_data.get("nickname"),
            "preferences": current_prefs,
        }

    @router.put("/api/me/preferences")
    def update_preferences(payload: PreferencesUpdate, user: User = Depends(get_current_user)):
        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(user.email))
        user_snap = user_ref.get()
        now = datetime.now(timezone.utc)
        user_data = user_snap.to_dict() if user_snap.exists and user_snap.to_dict() else {}
        current_prefs = dict(user_data.get("preferences", {}))

        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is not None:
                current_prefs[k] = v
        if hasattr(payload, "__pydantic_extra__") and payload.__pydantic_extra__:
            for k, v in payload.__pydantic_extra__.items():
                if v is not None:
                    current_prefs[k] = v

        user_ref.set(
            {
                "email": user.email,
                "preferences": current_prefs,
                "updated_at": now,
            },
            merge=True,
        )

        return {
            "email": user.email,
            "preferences": current_prefs,
        }

    @router.put("/api/users/{target_email}/preferences")
    def update_user_preferences_admin(
        target_email: str,
        payload: dict,
        user: User = Depends(get_current_user),
    ):
        if not (is_game_admin(user, service_name) or is_super_admin(user)):
            raise HTTPException(
                status_code=403,
                detail="Only Game Admins or Super Admins can edit user preferences.",
            )
        norm_target = db_module.normalize_email(target_email)
        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(norm_target))
        user_snap = user_ref.get()
        if not user_snap.exists:
            raise HTTPException(status_code=404, detail="User not found.")
        now = datetime.now(timezone.utc)
        user_data = user_snap.to_dict() or {}
        current_prefs = dict(user_data.get("preferences", {}))
        current_prefs.update(payload)
        user_ref.set({"preferences": current_prefs, "updated_at": now}, merge=True)
        return {"email": norm_target, "preferences": current_prefs}

    @router.post("/api/auth/check-email")
    def check_email_preapproved(payload: EmailCheckRequest):
        """Verifies an email is pre-registered before sending a Firebase Magic Link (prevents quota abuse)."""
        norm_email = db_module.normalize_email(str(payload.email))
        if dev_mode_enabled() or norm_email in auth.organizer_emails():
            return {"allowed": True}
        db = db_module.users_database()
        snap = db.collection(USERS_COLLECTION).document(db_module.user_key(norm_email)).get()
        if not snap.exists:
            raise HTTPException(
                status_code=403,
                detail="Registration is restricted. New users must be added by an administrator.",
            )
        return {"allowed": True}

    @router.get("/api/users")
    def list_users(
        q: str = "",
        limit: int = Query(default=500, ge=1, le=2000),
        user: User = Depends(get_current_user),
    ):
        db = db_module.users_database()
        query_str = q.strip().lower()
        results = []

        for doc in db.collection(USERS_COLLECTION).stream():
            data = doc.to_dict()
            if not data:
                continue
            email = data.get("email", "")
            display_name = data.get("display_name", "")
            nickname = data.get("nickname", "")
            if query_str:
                matches = (
                    query_str in email.lower()
                    or query_str in display_name.lower()
                    or query_str in nickname.lower()
                )
                if not matches:
                    continue

            last_login = data.get("last_login_at")
            last_log = data.get("last_log_at")
            system_role = data.get("system_role")
            roles = data.get("roles", {})
            results.append(
                {
                    "email": email,
                    "display_name": db_module.format_short_name(display_name or email),
                    "nickname": db_module.format_short_name(nickname or display_name or email),
                    "roles": roles,
                    "system_role": system_role,
                    "is_super_admin": email in auth.organizer_emails() or system_role == "super_admin",
                    "is_game_admin": email in auth.organizer_emails()
                    or system_role == "super_admin"
                    or any(roles.get(k) in ("game_admin", "admin") for k in service_role_keys(service_name)),
                    "last_login_at": last_login.isoformat()
                    if hasattr(last_login, "isoformat")
                    else (str(last_login) if last_login else None),
                    "last_log_at": last_log.isoformat()
                    if hasattr(last_log, "isoformat")
                    else (str(last_log) if last_log else None),
                    "preferences": data.get("preferences", {}),
                    "proxies": [p.strip().lower() for p in data.get("proxies", []) if isinstance(p, str)],
                }
            )

        sorted_results = sorted(results, key=lambda item: item["display_name"].lower())
        return sorted_results[:limit]

    @router.put("/api/users/{target_email}/role")
    def update_user_role(
        target_email: str,
        payload: UserRoleUpdate,
        user: User = Depends(get_current_user),
    ):
        if not is_super_admin(user):
            raise HTTPException(
                status_code=403,
                detail="Only Super Admins can manage game admin roles.",
            )

        norm_email = db_module.normalize_email(target_email)
        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(norm_email))
        user_snap = user_ref.get()
        now = datetime.now(timezone.utc)
        user_data = user_snap.to_dict() if user_snap.exists and user_snap.to_dict() else {}
        roles = dict(user_data.get("roles", {}))

        target_service = payload.service or service_name
        if payload.role in ("game_admin", "admin"):
            roles[target_service] = "game_admin"
        else:
            for k in service_role_keys(target_service):
                roles.pop(k, None)

        user_ref.set(
            {
                "email": norm_email,
                "roles": roles,
                "updated_at": now,
            },
            merge=True,
        )
        return {
            "email": norm_email,
            "service": target_service,
            "role": payload.role,
            "roles": roles,
        }

    @router.post("/api/users", status_code=201)
    def create_user(payload: UserCreateRequest, user: User = Depends(get_current_user)):
        caller_is_super = is_super_admin(user)
        if not (is_game_admin(user, service_name) or caller_is_super):
            raise HTTPException(
                status_code=403,
                detail="Only Game Admins or Super Admins can add new users.",
            )
        if payload.role in ("game_admin", "admin") and not caller_is_super:
            raise HTTPException(
                status_code=403,
                detail="Only Super Admins can assign game admin roles.",
            )

        norm_email = db_module.normalize_email(str(payload.email))
        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(norm_email))
        now = datetime.now(timezone.utc)
        user_doc = user_ref.get()
        user_data = user_doc.to_dict() if user_doc.exists and user_doc.to_dict() else {}

        existing_name = (user_data.get("display_name") or "").strip()
        existing_nick = (user_data.get("nickname") or "").strip()
        requested_name = (payload.display_name or payload.nickname or "").strip()
        requested_nick = (payload.nickname or payload.display_name or "").strip()
        default_name = norm_email.split("@")[0].replace(".", " ").title()

        if user_doc.exists and not caller_is_super:
            name = existing_name or requested_name or default_name
            nickname = existing_nick or requested_nick or name
        else:
            name = requested_name or existing_name or default_name
            nickname = requested_nick or existing_nick or name

        doc_payload = {
            "email": norm_email,
            "display_name": name,
            "nickname": nickname,
            "updated_at": now,
        }
        if not user_doc.exists:
            doc_payload["created_at"] = now
            doc_payload["added_by"] = user.email

        roles = dict(user_data.get("roles", {}))
        if payload.role in ("game_admin", "admin") and caller_is_super:
            roles[service_name] = "game_admin"
            doc_payload["roles"] = roles

        user_ref.set(doc_payload, merge=True)

        return {
            "email": norm_email,
            "display_name": db_module.format_short_name(name),
            "nickname": db_module.format_short_name(nickname),
            "roles": roles,
            "created": not user_doc.exists,
        }

    @router.delete("/api/users/{target_email}", status_code=204)
    def delete_user(target_email: str, user: User = Depends(get_current_user)):
        if not is_super_admin(user):
            raise HTTPException(
                status_code=403,
                detail="Only Super Admins can permanently delete platform users.",
            )
        norm_target = db_module.normalize_email(target_email)
        if norm_target == user.email.strip().lower():
            raise HTTPException(status_code=400, detail="You cannot delete yourself.")
        if is_super_admin(User(norm_target, "", "")):
            raise HTTPException(status_code=403, detail="Super Admins cannot be deleted.")

        db = db_module.users_database()
        user_ref = db.collection(USERS_COLLECTION).document(db_module.user_key(norm_target))
        user_ref.delete()
        return None

    return router
