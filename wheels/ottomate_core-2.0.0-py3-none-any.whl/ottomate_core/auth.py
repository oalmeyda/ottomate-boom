import base64
from dataclasses import dataclass
from functools import lru_cache
import json
import os

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from google.auth.transport import requests as google_requests
from google.oauth2 import id_token

from ottomate_core.db import normalize_email

bearer_scheme = HTTPBearer(auto_error=False)

# Used only when DEV_MODE is enabled and no explicit email is supplied.
DEV_FALLBACK_EMAIL = "dev@example.com"


@dataclass(frozen=True)
class User:
    email: str
    subject: str = ""
    display_name: str = ""

    def __init__(
        self,
        email: str = "",
        subject: str = "",
        display_name: str = "",
        sub: str = "",
        user_id: str = "",
        name: str = "",
        roles: list[str] | None = None,
    ):
        resolved_email = email or user_id
        resolved_subject = subject or sub or f"user-sub-{resolved_email}"
        resolved_name = display_name or name or resolved_email
        object.__setattr__(self, "email", resolved_email)
        object.__setattr__(self, "subject", resolved_subject)
        object.__setattr__(self, "display_name", resolved_name)

    @property
    def sub(self) -> str:
        return self.subject

    @property
    def user_id(self) -> str:
        return self.email

    @property
    def name(self) -> str:
        return self.display_name



@lru_cache
def google_client_id() -> str:
    return os.environ.get("GOOGLE_CLIENT_ID", "").strip()


@lru_cache
def firebase_project_id() -> str:
    return (
        os.environ.get("FIREBASE_PROJECT_ID", "").strip()
        or os.environ.get("GOOGLE_CLOUD_PROJECT", "").strip()
        or "ottomate-gaming-platform"
    )


@lru_cache
def firebase_api_key() -> str:
    return os.environ.get("FIREBASE_API_KEY", "").strip()


@lru_cache
def firebase_auth_domain() -> str:
    return (
        os.environ.get("FIREBASE_AUTH_DOMAIN", "").strip()
        or f"{firebase_project_id()}.firebaseapp.com"
    )


def firebase_config() -> dict[str, str] | None:
    """Returns Firebase web SDK configuration if FIREBASE_API_KEY is configured, else None."""
    api_key = firebase_api_key()
    if not api_key:
        return None
    return {
        "apiKey": api_key,
        "authDomain": firebase_auth_domain(),
        "projectId": firebase_project_id(),
    }


def _get_token_issuer(token: str) -> str:
    """Inspects the unverified JWT payload to extract the 'iss' (issuer) claim without verifying signature."""
    try:
        parts = token.split(".")
        if len(parts) >= 2:
            rem = len(parts[1]) % 4
            padded = parts[1] + ("=" * (4 - rem) if rem else "")
            payload = json.loads(base64.urlsafe_b64decode(padded).decode("utf-8"))
            return payload.get("iss", "")
    except Exception:
        pass
    return ""


_organizer_emails_provider = None


def set_organizer_emails_provider(provider):
    """Overrides the Super Admin email source (pass `None` to restore the env default)."""
    global _organizer_emails_provider
    _organizer_emails_provider = provider


def organizer_emails() -> frozenset[str]:
    """Returns the Super Admin email allow-list.

    Services/tests can override the source with `set_organizer_emails_provider()`;
    otherwise the comma-separated `ORGANIZER_EMAILS` environment variable is used.
    """
    if _organizer_emails_provider is not None:
        return _organizer_emails_provider()
    return _get_organizer_emails()


@lru_cache
def _get_organizer_emails() -> frozenset[str]:
    return frozenset(
        normalize_email(email)
        for email in os.environ.get("ORGANIZER_EMAILS", "").split(",")
        if email.strip()
    )


organizer_emails.cache_clear = _get_organizer_emails.cache_clear


@lru_cache
def dev_mode_enabled() -> bool:
    return os.environ.get("DEV_MODE", "").lower() in ("1", "true", "yes")


def _verify_firebase_id_token_strict(token: str, fb_project: str) -> dict:
    """Verifies a Firebase Auth ID token and strictly enforces issuer and non-empty subject."""
    if not fb_project:
        raise ValueError("Firebase project ID is not configured.")
    claims = id_token.verify_firebase_token(
        token,
        google_requests.Request(),
        audience=fb_project,
    )
    expected_iss = f"https://securetoken.google.com/{fb_project}"
    if claims.get("iss") != expected_iss:
        raise ValueError(f"Invalid Firebase token issuer '{claims.get('iss')}' (expected '{expected_iss}').")
    if not claims.get("sub"):
        raise ValueError("Firebase token missing non-empty 'sub' claim.")
    return claims


def verify_bearer_token(token: str) -> User:
    """Verifies a Bearer token (dev token in DEV_MODE, Google OAuth2 ID token, or Firebase Auth ID token)."""
    if dev_mode_enabled() and token:
        if token.startswith("dev:"):
            raw_email = token.split("dev:", 1)[1] or DEV_FALLBACK_EMAIL
            email = normalize_email(raw_email)
            return User(
                email=email,
                subject=f"dev-sub-{email}",
                display_name=email.split("@")[0].replace(".", " ").title(),
            )
        if token == "dev-token":
            default_org = next(iter(organizer_emails()), DEV_FALLBACK_EMAIL)
            return User(
                email=default_org,
                subject="dev-sub-organizer",
                display_name="Dev Organizer",
            )

    client_id = google_client_id()
    fb_project = firebase_project_id()
    fb_enabled = bool(firebase_api_key())

    iss = _get_token_issuer(token)
    claims = None
    last_exc = None

    if iss.startswith("https://securetoken.google.com/"):
        # Explicit Firebase ID Token (e.g. from Firebase Auth Email Link)
        try:
            claims = _verify_firebase_id_token_strict(token, fb_project)
        except Exception as exc:
            last_exc = exc
    else:
        # Standard Google OAuth2 ID Token
        if client_id:
            try:
                claims = id_token.verify_oauth2_token(
                    token,
                    google_requests.Request(),
                    client_id,
                )
            except Exception as exc:
                last_exc = exc
        else:
            if fb_enabled and fb_project:
                try:
                    claims = _verify_firebase_id_token_strict(token, fb_project)
                except Exception:
                    pass
            if not claims:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="Google Client ID is not configured on the server.",
                )

        # Fallback: if OAuth verification failed and Firebase Email Auth is enabled, try Firebase verification
        if not claims and fb_enabled and fb_project:
            try:
                claims = _verify_firebase_id_token_strict(token, fb_project)
                last_exc = None
            except Exception:
                pass

    if not claims:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid ID token: {last_exc}" if last_exc else "Invalid authentication token.",
        ) from last_exc

    raw_email = claims.get("email")
    if not raw_email or not claims.get("email_verified", False):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token does not contain a verified email address.",
        )

    return User(
        email=normalize_email(raw_email),
        subject=claims.get("sub", ""),
        display_name=claims.get("name") or raw_email,
    )


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
) -> User:
    if not credentials or not credentials.credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing Authorization header.",
        )
    return verify_bearer_token(credentials.credentials)

