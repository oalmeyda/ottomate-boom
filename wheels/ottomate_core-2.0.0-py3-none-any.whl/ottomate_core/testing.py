"""Shared in-memory Firestore test double and pytest helpers for Ottomate services.

Usage in a service's tests::

    from ottomate_core.testing import FakeDatabase, use_database, use_organizers

    def test_something(monkeypatch):
        db = FakeDatabase()
        use_database(monkeypatch, db)
        use_organizers(monkeypatch, ["admin@example.com"])
"""

from __future__ import annotations

from typing import Any, Iterable


class FakeSnapshot:
    def __init__(self, document_id: str, data: dict | None, reference: Any = None):
        self.id = document_id
        self._data = data
        self.exists = data is not None
        self.reference = reference

    def to_dict(self) -> dict | None:
        return self._data

    def get(self, key, default=None):
        if self._data and isinstance(self._data, dict):
            return self._data.get(key, default)
        return default


class FakeDocument:
    def __init__(self, database: "FakeDatabase", path: tuple[str, ...]):
        self.database = database
        self.path = path
        self.id = path[-1]

    def collection(self, name: str) -> "FakeCollection":
        return FakeCollection(self.database, (*self.path, name))

    def get(self, transaction: Any = None) -> FakeSnapshot:
        return FakeSnapshot(self.id, self.database.documents.get(self.path), reference=self)

    def set(self, data: dict, merge: bool = False) -> None:
        from ottomate_core.db import to_firestore_dict

        clean_data = to_firestore_dict(data)
        if merge and self.path in self.database.documents:
            current = self.database.documents[self.path]
            if isinstance(current, dict) and isinstance(clean_data, dict):
                merged = dict(current)
                merged.update(clean_data)
                self.database.documents[self.path] = merged
                return
        self.database.documents[self.path] = clean_data

    def update(self, data: dict) -> None:
        from ottomate_core.db import to_firestore_dict

        clean_data = to_firestore_dict(data)
        current = dict(self.database.documents.get(self.path) or {})
        for key, val in clean_data.items():
            if isinstance(key, str) and "." in key:
                parts = key.split(".")
                cursor = current
                for part in parts[:-1]:
                    existing = cursor.get(part)
                    if not isinstance(existing, dict):
                        existing = {}
                    else:
                        existing = dict(existing)
                    cursor[part] = existing
                    cursor = existing
                cursor[parts[-1]] = val
            else:
                current[key] = val
        self.database.documents[self.path] = current

    def delete(self) -> None:
        self.database.documents.pop(self.path, None)


class FakeQuery:
    def __init__(self, collection: "FakeCollection", filters: tuple = (), limit: int | None = None):
        self.collection = collection
        self.filters = filters
        self._limit = limit

    def where(self, field: str, op: str, value: Any) -> "FakeQuery":
        return FakeQuery(self.collection, (*self.filters, (field, op, value)), self._limit)

    def limit(self, count: int) -> "FakeQuery":
        return FakeQuery(self.collection, self.filters, count)

    def order_by(self, field: str, direction: str | None = None) -> "FakeQuery":
        return self

    def stream(self):
        emitted = 0
        for snapshot in self.collection.stream():
            data = snapshot.to_dict()
            if not data or not isinstance(data, dict):
                continue
            matches = True
            for field, op, val in self.filters:
                if op == "==" and data.get(field) != val:
                    matches = False
                    break
                if op == "array_contains":
                    fval = data.get(field)
                    if not isinstance(fval, (list, tuple, set)) or val not in fval:
                        matches = False
                        break
            if matches:
                yield snapshot
                emitted += 1
                if self._limit is not None and emitted >= self._limit:
                    return


class FakeCollection:
    def __init__(self, database: "FakeDatabase", path: tuple[str, ...]):
        self.database = database
        self.path = path

    def document(self, document_id: str | None = None) -> FakeDocument:
        if document_id is None:
            self.database.next_id += 1
            document_id = f"{self.database.id_prefix}-{self.database.next_id}"
        return FakeDocument(self.database, (*self.path, document_id))

    def stream(self):
        prefix_length = len(self.path)
        for path, data in list(self.database.documents.items()):
            if path[:prefix_length] == self.path and len(path) == prefix_length + 1:
                yield FakeSnapshot(path[-1], data, reference=FakeDocument(self.database, path))

    def where(self, field: str, op: str, value: Any) -> FakeQuery:
        return FakeQuery(self, ((field, op, value),))

    def limit(self, count: int) -> FakeQuery:
        return FakeQuery(self, (), count)

    def order_by(self, field: str, direction: str | None = None) -> FakeQuery:
        return FakeQuery(self, ()).order_by(field, direction)


class FakeBatch:
    def __init__(self, database: "FakeDatabase"):
        self.database = database
        self.writes: list[tuple] = []

    def set(self, reference: FakeDocument, data: dict, merge: bool = False) -> None:
        self.writes.append(("set", reference, data, merge))

    def delete(self, reference: FakeDocument) -> None:
        self.writes.append(("delete", reference, None, False))

    def commit(self) -> None:
        for op, reference, data, merge in self.writes:
            if op == "set":
                reference.set(data, merge=merge)
            elif op == "delete":
                reference.delete()


class FakeTransaction:
    """In-memory transaction stand-in supporting get/set/update/delete."""

    def __init__(self, database: "FakeDatabase"):
        self.database = database
        self._read_only = False
        self._max_attempts = 1
        self._id = b"fake-tx"
        self._in_progress = False
        self.writes: list[tuple] = []

    def get(self, ref_or_query: Any) -> Any:
        if hasattr(ref_or_query, "stream"):
            return list(ref_or_query.stream())
        return ref_or_query.get()

    def set(self, reference: FakeDocument, data: dict, merge: bool = False) -> None:
        self.writes.append(("set", reference, data, merge))

    def update(self, reference: FakeDocument, data: dict) -> None:
        self.writes.append(("update", reference, data, False))

    def delete(self, reference: FakeDocument) -> None:
        self.writes.append(("delete", reference, None, False))

    def commit(self) -> None:
        for op, reference, data, merge in self.writes:
            if op == "set":
                reference.set(data, merge=merge)
            elif op == "update":
                reference.update(data)
            elif op == "delete":
                reference.delete()
        self.writes.clear()


class FakeDatabase:
    """Zero-dependency in-memory stand-in for `google.cloud.firestore.Client`.

    `id_prefix` controls auto-generated document IDs (e.g. "game" -> "game-1").
    """

    def __init__(self, id_prefix: str = "doc"):
        self.documents: dict[tuple[str, ...], dict | None] = {}
        self.next_id = 0
        self.id_prefix = id_prefix

    @property
    def docs(self) -> dict:  # Backwards-compatible alias used by older tests.
        return self.documents

    def collection(self, name: str) -> FakeCollection:
        return FakeCollection(self, (name,))

    def batch(self) -> FakeBatch:
        return FakeBatch(self)

    def transaction(self) -> FakeTransaction:
        return FakeTransaction(self)

    def get_all(self, references: Iterable[FakeDocument]):
        for ref in references:
            yield ref.get()


def use_database(monkeypatch, database: FakeDatabase, *, separate_users_db: bool = False) -> FakeDatabase:
    """Routes every `ottomate_core.db.database()` call to `database` for the test.

    When `separate_users_db=True`, `users_database()` is routed to an isolated
    `FakeDatabase(id_prefix="user")` so split-brain queries to `database().collection("users")`
    are immediately caught.
    """
    from ottomate_core import db as core_db

    monkeypatch.setattr(core_db, "_database_provider", lambda db_name=None: database)
    if separate_users_db:
        users_db = FakeDatabase(id_prefix="user")
        monkeypatch.setattr(core_db, "_users_database_provider", lambda: users_db)
    return database


def use_users_database(monkeypatch, database: FakeDatabase) -> FakeDatabase:
    """Routes every `ottomate_core.db.users_database()` call to `database` for the test."""
    from ottomate_core import db as core_db

    monkeypatch.setattr(core_db, "_users_database_provider", lambda: database)
    return database


def use_organizers(monkeypatch, emails: Iterable[str]) -> frozenset[str]:
    """Overrides the Super Admin email list for the test."""
    from ottomate_core import auth as core_auth

    normalized = frozenset(e.strip().lower() for e in emails)
    monkeypatch.setattr(core_auth, "_organizer_emails_provider", lambda: normalized)
    return normalized


def verify_vendored_core_wheel(repo_root) -> None:
    """Asserts that `wheels/ottomate_core-*.whl` exists and satisfies the `ottomate-core` pin in `pyproject.toml`."""
    from pathlib import Path
    import re
    import tomllib

    root = Path(repo_root)
    pyproject_path = root / "pyproject.toml"
    with open(pyproject_path, "rb") as f:
        data = tomllib.load(f)

    deps = data["project"].get("dependencies", [])
    core_dep = next((d for d in deps if d.startswith("ottomate-core")), None)
    if not core_dep:
        return

    wheels_dir = root / "wheels"
    assert wheels_dir.exists(), "wheels/ directory must exist when ottomate-core is a dependency"
    wheels = sorted(wheels_dir.glob("ottomate_core-*.whl"))
    assert len(wheels) > 0, "wheels/ directory must contain at least one ottomate_core-*.whl"

    def _parse_ver(v: str) -> tuple[int, ...]:
        return tuple(int(part) for part in re.findall(r"\d+", v))

    min_match = re.search(r">=\s*([0-9]+(?:\.[0-9]+)*)", core_dep)
    eq_match = re.search(r"==\s*([0-9]+(?:\.[0-9]+)*)", core_dep)

    wheel_versions = []
    for whl in wheels:
        m = re.match(r"ottomate_core-([0-9]+(?:\.[0-9]+)*)-", whl.name)
        if m:
            wheel_versions.append(m.group(1))
    assert wheel_versions, f"Could not parse version from wheels: {[w.name for w in wheels]}"

    if eq_match:
        required = eq_match.group(1)
        assert required in wheel_versions, (
            f"pyproject.toml requires {core_dep}, but wheels/ only has {wheel_versions}."
        )
    elif min_match:
        required_min = _parse_ver(min_match.group(1))
        assert any(_parse_ver(v) >= required_min for v in wheel_versions), (
            f"pyproject.toml requires {core_dep}, but wheels/ only has {wheel_versions}."
        )


def verify_service_version_consistency(
    repo_root,
    expected_version: str,
    *,
    app=None,
    index_file=None,
) -> None:
    """Verifies pyproject.toml, CHANGELOG.md, index.html, /api/config, and wheels/ consistency."""
    from pathlib import Path
    import re
    import tomllib

    root = Path(repo_root)
    pyproject_path = root / "pyproject.toml"
    assert pyproject_path.exists(), "pyproject.toml must exist"

    with open(pyproject_path, "rb") as f:
        data = tomllib.load(f)

    pyproject_version = data["project"]["version"]
    assert pyproject_version == expected_version, (
        f"Version mismatch: pyproject.toml has '{pyproject_version}' "
        f"but expected_version is '{expected_version}'."
    )

    changelog_path = root / "CHANGELOG.md"
    assert changelog_path.exists(), "CHANGELOG.md must exist"
    changelog_content = changelog_path.read_text(encoding="utf-8")
    expected_header = f"## [{expected_version}]"
    assert expected_header in changelog_content, (
        f"CHANGELOG.md missing release section for '{expected_header}'."
    )

    if index_file is not None:
        idx_path = Path(index_file)
        assert idx_path.exists(), f"index.html must exist at {idx_path}"
        html_content = idx_path.read_text(encoding="utf-8")
        match = re.search(r'id=["\']app-version["\'][^>]*>([^<]+)<', html_content)
        assert match, "Could not find element with id='app-version' in index.html"
        rendered_text = match.group(1).strip()
        assert rendered_text == f"v{expected_version}", (
            f"Stale version in index.html: found '{rendered_text}', expected 'v{expected_version}'."
        )

        stale_queries = [
            m.group(0)
            for m in re.finditer(r'(?:/core-static/|/static/)[^"\'?\s>]+\?v=([^"\'\s>]+)', html_content)
            if m.group(1) != expected_version
        ]
        assert not stale_queries, (
            f"Stale asset cache-busting version query param in {idx_path}: "
            f"found {stale_queries}, expected '?v={expected_version}'."
        )

    if app is not None:
        from fastapi.testclient import TestClient

        with TestClient(app) as client:
            res = client.get("/api/config")
            assert res.status_code == 200
            payload = res.json()
            assert payload.get("version") == expected_version, (
                f"/api/config returned version '{payload.get('version')}', expected '{expected_version}'."
            )

    verify_vendored_core_wheel(root)

