"""Standard 52-card deck representation, shuffling, and dealing utilities."""

from __future__ import annotations
from enum import Enum
import random
from typing import Any, Mapping

from pydantic import ConfigDict

from ottomate_core.models import DictCompatibleModel


class Suit(str, Enum):
    SPADES = "S"
    HEARTS = "H"
    DIAMONDS = "D"
    CLUBS = "C"


SUITS: list[str] = ["S", "H", "D", "C"]
SUIT_SYMBOLS: dict[str, str] = {"S": "♠", "H": "♥", "D": "♦", "C": "♣"}
SUIT_NAMES: dict[str, str] = {"S": "Spades", "H": "Hearts", "D": "Diamonds", "C": "Clubs"}
SUIT_COLORS: dict[str, str] = {"S": "black", "H": "red", "D": "red", "C": "black"}

RANK_NAMES: dict[int, str] = {
    2: "2", 3: "3", 4: "4", 5: "5", 6: "6", 7: "7", 8: "8", 9: "9", 10: "10",
    11: "Jack", 12: "Queen", 13: "King", 14: "Ace",
}

RANK_LABELS: dict[int, str] = {
    2: "2", 3: "3", 4: "4", 5: "5", 6: "6", 7: "7", 8: "8", 9: "9", 10: "10",
    11: "J", 12: "Q", 13: "K", 14: "A",
}


class Card(DictCompatibleModel):
    """Strongly-typed playing card model with dict-access compatibility."""

    model_config = ConfigDict(frozen=True, extra="allow")

    id: str
    rank: int
    suit: str
    label: str
    suit_symbol: str
    suit_name: str = ""
    color: str = "black"

    @classmethod
    def create(cls, rank: int, suit: str) -> "Card":
        clean_suit = suit.strip().upper()
        if clean_suit not in SUIT_SYMBOLS and len(clean_suit) > 1:
            clean_suit = clean_suit[0]
        if rank not in RANK_LABELS:
            raise ValueError(f"Invalid card rank: {rank}")
        if clean_suit not in SUIT_SYMBOLS:
            raise ValueError(f"Invalid card suit: {suit}")
        return cls(
            id=f"{rank}_{clean_suit}",
            rank=rank,
            suit=clean_suit,
            label=RANK_LABELS[rank],
            suit_symbol=SUIT_SYMBOLS[clean_suit],
            suit_name=SUIT_NAMES[clean_suit],
            color=SUIT_COLORS[clean_suit],
        )

    @classmethod
    def hidden(cls, index: int = 0) -> "Card":
        """Creates a masked face-down card placeholder for anti-cheat network responses."""
        return cls(
            id=f"hidden_{index}",
            rank=0,
            suit="hidden",
            label="?",
            suit_symbol="🂠",
            suit_name="Hidden",
            color="blue",
        )

    @classmethod
    def from_raw(cls, value: "Card | Mapping[str, Any]") -> "Card":
        if isinstance(value, cls):
            return value
        if isinstance(value, Mapping):
            suit = str(value.get("suit", "S"))
            rank = int(value.get("rank", 0))
            if suit == "hidden":
                return cls(
                    id=str(value.get("id", "hidden_0")),
                    rank=rank,
                    suit="hidden",
                    label=str(value.get("label", "?")),
                    suit_symbol=str(value.get("suit_symbol", "🂠")),
                    suit_name=str(value.get("suit_name", "Hidden")),
                    color=str(value.get("color", "blue")),
                )
            return cls(
                id=str(value.get("id", f"{rank}_{suit}")),
                rank=rank,
                suit=suit,
                label=str(value.get("label") or RANK_LABELS.get(rank, str(rank))),
                suit_symbol=str(value.get("suit_symbol") or SUIT_SYMBOLS.get(suit, suit)),
                suit_name=str(value.get("suit_name") or SUIT_NAMES.get(suit, suit)),
                color=str(value.get("color") or SUIT_COLORS.get(suit, "black")),
            )
        raise TypeError(f"Cannot convert {type(value)!r} to Card")


def make_card(rank: int, suit: str) -> Card:
    """Creates a validated Card domain object (compatible with both attribute and dict access)."""
    return Card.create(rank, suit)


def create_deck() -> list[Card]:
    """Returns an ordered 52-card standard deck as Card objects."""
    return [Card.create(r, s) for s in SUITS for r in range(2, 15)]


def create_shuffled_deck(seed: int | str | None = None) -> list[Card]:
    """Returns a shuffled 52-card deck with optional deterministic seed."""
    deck = create_deck()
    rng = random.Random(seed) if seed is not None else random.Random()
    rng.shuffle(deck)
    return deck


class Deck:
    """Standard 52-card playing deck with deterministic dealing and shuffling."""

    @staticmethod
    def standard_52() -> list[Card]:
        return create_deck()

    @classmethod
    def shuffled(cls, seed: int | str | None = None) -> list[Card]:
        return create_shuffled_deck(seed)

    @classmethod
    def deal_hands(
        cls,
        num_players: int,
        cards_per_player: int,
        seed: int | str | None = None,
    ) -> tuple[list[list[Card]], list[Card]]:
        """Deals cards_per_player to num_players. Returns (hands, remaining_deck)."""
        if num_players * cards_per_player > 52:
            raise ValueError(
                f"Cannot deal {num_players} x {cards_per_player} = "
                f"{num_players * cards_per_player} cards from a 52-card deck."
            )
        deck = cls.shuffled(seed)
        hands = []
        for i in range(num_players):
            hand = deck[i * cards_per_player : (i + 1) * cards_per_player]
            sorted_hand = sorted(hand, key=lambda c: (c.suit, c.rank))
            hands.append(sorted_hand)
        remaining = deck[num_players * cards_per_player :]
        return hands, remaining
