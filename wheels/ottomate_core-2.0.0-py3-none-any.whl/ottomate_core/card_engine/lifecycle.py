"""Standardized turn pacing, trick review holds, and test lifecycle helpers for scale-to-zero games."""

from __future__ import annotations
from datetime import datetime, timezone
import os


def format_iso_now() -> str:
    """Returns current UTC timestamp in ISO 8601 format."""
    return datetime.now(timezone.utc).isoformat()


class PacingController:
    """Orchestrates human pacing delays and review holds across serverless turn games."""

    def __init__(
        self,
        bot_delay_seconds: float = 2.0,
        trick_hold_seconds: float = 2.5,
        round_hold_seconds: float = 4.0,
        *,
        honor_delays_in_tests: bool = False,
    ) -> None:
        self.bot_delay_seconds = bot_delay_seconds
        self.trick_hold_seconds = trick_hold_seconds
        self.round_hold_seconds = round_hold_seconds
        self.honor_delays_in_tests = honor_delays_in_tests

    @property
    def is_test_mode(self) -> bool:
        """True if running inside an automated test suite (disables sleep / delays unless honor_delays_in_tests is True)."""
        if self.honor_delays_in_tests:
            return "FAST_TEST_MODE" in os.environ
        return "PYTEST_CURRENT_TEST" in os.environ or "FAST_TEST_MODE" in os.environ

    def is_bot_ready(
        self,
        last_action_at: str | None,
        delay_seconds: float | None = None,
        force: bool = False,
    ) -> bool:
        """Evaluates whether sufficient time has elapsed since the last bot/player action."""
        if force or self.is_test_mode:
            return True
        if not last_action_at:
            return True

        req_delay = delay_seconds if delay_seconds is not None else self.bot_delay_seconds
        try:
            last_dt = datetime.fromisoformat(last_action_at)
            elapsed = (datetime.now(timezone.utc) - last_dt).total_seconds()
            return elapsed >= req_delay
        except Exception:
            return True

    def is_trick_hold_expired(
        self,
        trick_completed_at: str | None,
        hold_seconds: float | None = None,
        force: bool = False,
    ) -> bool:
        """Evaluates whether the completed trick review hold (showing winner & chips) has completed."""
        if force or self.is_test_mode:
            return True
        if not trick_completed_at:
            return True

        req_hold = hold_seconds if hold_seconds is not None else self.trick_hold_seconds
        try:
            comp_dt = datetime.fromisoformat(trick_completed_at)
            elapsed = (datetime.now(timezone.utc) - comp_dt).total_seconds()
            return elapsed >= req_hold
        except Exception:
            return True

    def should_hold_round_summary(
        self,
        round_completed_at: str | None,
        hold_seconds: float | None = None,
        force: bool = False,
    ) -> bool:
        """Evaluates whether the round summary modal / transition should remain active."""
        if force or self.is_test_mode:
            return False
        if not round_completed_at:
            return False

        req_hold = hold_seconds if hold_seconds is not None else self.round_hold_seconds
        try:
            comp_dt = datetime.fromisoformat(round_completed_at)
            elapsed = (datetime.now(timezone.utc) - comp_dt).total_seconds()
            return elapsed < req_hold
        except Exception:
            return False


# Shared default instance
default_pacing = PacingController()

