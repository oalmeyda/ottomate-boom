"""Euchre-specific 24-card deck representation, Bower mechanics, follow-suit rules, and trick evaluation.

Standard North American Euchre:
- 24 cards: 9, 10, J, Q, K, A in ♠, ♥, ♦, ♣.
- Right Bower: Jack of the trump suit (highest card in the game).
- Left Bower: Jack of the same-color suit (second highest card, legally counts as trump).
- Same color suit pairs:
    Spades (♠) <-> Clubs (♣)
    Hearts (♥) <-> Diamonds (♦)
"""

from __future__ import annotations
import random
from typing import Any, Mapping, Sequence

from ottomate_core.card_engine.cards import (
    SUITS,
    SUIT_SYMBOLS,
    Card,
)
from ottomate_core.card_engine.trick import (
    TrickPlay,
    TrickWinnerExplanation,
)

# Supported Euchre deck sizes:
# - 20 cards: 10 through Ace (Short / Stripped Euchre)
# - 24 cards: 9 through Ace (Standard North American Euchre)
# - 32 cards: 7 through Ace (British / European / Australian Euchre)
EUCHRE_DECK_SIZES: tuple[int, ...] = (20, 24, 32)

EUCHRE_RANKS_BY_SIZE: dict[int, list[int]] = {
    20: [10, 11, 12, 13, 14],
    24: [9, 10, 11, 12, 13, 14],
    32: [7, 8, 9, 10, 11, 12, 13, 14],
}

# Standard 24-card Euchre card ranks (for backward compatibility)
EUCHRE_RANKS: list[int] = EUCHRE_RANKS_BY_SIZE[24]

# Same color suit mapping (Black pairs, Red pairs)
SAME_COLOR_SUIT: dict[str, str] = {
    "S": "C",
    "C": "S",
    "H": "D",
    "D": "H",
}

# Effective rank constants for Bowers
RIGHT_BOWER_RANK: int = 16
LEFT_BOWER_RANK: int = 15


def create_euchre_deck(deck_size: int = 24) -> list[Card]:
    """Returns an ordered Euchre deck for the given deck_size (20, 24, or 32 cards)."""
    size = deck_size if deck_size in EUCHRE_RANKS_BY_SIZE else 24
    ranks = EUCHRE_RANKS_BY_SIZE[size]
    return [Card.create(r, s) for s in SUITS for r in ranks]


def create_shuffled_euchre_deck(deck_size: int = 24, seed: int | str | None = None) -> list[Card]:
    """Returns a shuffled Euchre deck with optional deterministic seed."""
    deck = create_euchre_deck(deck_size=deck_size)
    rng = random.Random(seed) if seed is not None else random.Random()
    rng.shuffle(deck)
    return deck


def is_right_bower(card: Card | Mapping[str, Any], trump_suit: str) -> bool:
    """Returns True if the card is the Jack of the trump suit."""
    clean_trump = str(trump_suit).strip().upper()
    return int(card.get("rank") or 0) == 11 and str(card.get("suit") or "").upper() == clean_trump


def is_left_bower(card: Card | Mapping[str, Any], trump_suit: str) -> bool:
    """Returns True if the card is the Jack of the same-color suit as trump."""
    clean_trump = str(trump_suit).strip().upper()
    partner_suit = SAME_COLOR_SUIT.get(clean_trump, "")
    return int(card.get("rank") or 0) == 11 and str(card.get("suit") or "").upper() == partner_suit


def get_euchre_effective_suit(card: Card | Mapping[str, Any], trump_suit: str) -> str:
    """Returns the effective suit of a card under the active trump suit.
    
    CRITICAL EUCHRE RULE:
    The Left Bower (Jack of the same-color suit) legally counts as the TRUMP suit
    for all purposes: following suit, trick evaluation, and ruffing.
    """
    clean_trump = str(trump_suit).strip().upper()
    if is_right_bower(card, clean_trump) or is_left_bower(card, clean_trump):
        return clean_trump
    return str(card.get("suit") or "").upper()


def get_euchre_effective_rank(card: Card | Mapping[str, Any], trump_suit: str) -> int:
    """Returns the effective rank of a card under the active trump suit.
    
    Ranking in trump:
        Right Bower: 16
        Left Bower: 15
        Ace: 14
        King: 13
        Queen: 12
        10: 10
        9: 9
    """
    clean_trump = str(trump_suit).strip().upper()
    if is_right_bower(card, clean_trump):
        return RIGHT_BOWER_RANK
    if is_left_bower(card, clean_trump):
        return LEFT_BOWER_RANK
    return int(card.get("rank") or 0)


def get_euchre_card_label(card: Card | Mapping[str, Any], trump_suit: str) -> str:
    """Returns a readable label for the card, highlighting Bowers."""
    clean_trump = str(trump_suit).strip().upper()
    if is_right_bower(card, clean_trump):
        symbol = SUIT_SYMBOLS.get(clean_trump, clean_trump)
        return f"Right Bower (J{symbol})"
    if is_left_bower(card, clean_trump):
        symbol = card.get("suit_symbol") or SUIT_SYMBOLS.get(str(card.get("suit")), "")
        return f"Left Bower (J{symbol})"
    label = card.get("label") or str(card.get("rank"))
    symbol = card.get("suit_symbol") or SUIT_SYMBOLS.get(str(card.get("suit")), "")
    return f"{label}{symbol}"


def is_legal_euchre_play(
    hand: Sequence[Card | Mapping[str, Any]],
    card_to_play: Card | Mapping[str, Any],
    lead_card: Card | Mapping[str, Any] | None,
    trump_suit: str,
) -> bool:
    """Validates the standard Euchre 'follow suit' rule.
    
    1. The card must exist in the player's current hand.
    2. If no lead card has been played in this trick, any card in hand is legal.
    3. If a lead card exists, the player MUST play a card whose *effective suit*
       matches the lead card's *effective suit* if they hold one.
       Remember: Left Bower is TRUMP, NOT its printed suit!
    4. If the player is void in the lead effective suit, they may play any card.
    """
    target_id = card_to_play.get("id")
    if not any(c.get("id") == target_id for c in hand):
        return False
    if lead_card is None:
        return True

    clean_trump = str(trump_suit).strip().upper()
    lead_effective_suit = get_euchre_effective_suit(lead_card, clean_trump)
    card_effective_suit = get_euchre_effective_suit(card_to_play, clean_trump)

    has_lead_suit = any(
        get_euchre_effective_suit(c, clean_trump) == lead_effective_suit
        for c in hand
    )
    if has_lead_suit:
        return card_effective_suit == lead_effective_suit
    return True


def get_legal_euchre_plays(
    hand: Sequence[Card | Mapping[str, Any]],
    lead_card: Card | Mapping[str, Any] | None,
    trump_suit: str,
) -> list[Card]:
    """Returns the list of legal Card plays from a hand given lead card and trump."""
    clean_trump = str(trump_suit).strip().upper()
    legal: list[Card] = []
    for raw in hand:
        card = Card.from_raw(raw)
        if is_legal_euchre_play(hand, card, lead_card, clean_trump):
            legal.append(card)
    return legal


def evaluate_euchre_trick_winner(
    trick_plays: Sequence[TrickPlay | Mapping[str, Any]],
    trump_suit: str,
) -> str:
    """Evaluates the winner of a completed Euchre trick.
    
    1. If any trump card (including Right or Left Bower) was played:
       The highest effective trump rank wins.
    2. If no trump was played:
       The highest card of the lead effective suit wins.
    """
    if not trick_plays:
        raise ValueError("Cannot evaluate an empty trick")

    clean_trump = str(trump_suit).strip().upper()
    lead_card = trick_plays[0]["card"] if isinstance(trick_plays[0], Mapping) else trick_plays[0].card
    lead_effective_suit = get_euchre_effective_suit(lead_card, clean_trump)

    best_player: str = ""
    best_is_trump: bool = False
    best_rank: int = -1

    for play in trick_plays:
        player = play.get("player") or play.get("player_email") if isinstance(play, Mapping) else play.player
        c = play["card"] if isinstance(play, Mapping) else play.card
        eff_suit = get_euchre_effective_suit(c, clean_trump)
        eff_rank = get_euchre_effective_rank(c, clean_trump)

        is_trump = (eff_suit == clean_trump)

        if not best_player:
            best_player = player
            best_is_trump = is_trump
            best_rank = eff_rank
            continue

        if is_trump and not best_is_trump:
            # First trump beats non-trump lead
            best_player = player
            best_is_trump = True
            best_rank = eff_rank
        elif is_trump and best_is_trump:
            # Higher trump beats lower trump (Right Bower 16 > Left Bower 15 > A 14 > ...)
            if eff_rank > best_rank:
                best_player = player
                best_rank = eff_rank
        elif not is_trump and not best_is_trump:
            # In off-suit, must match lead suit and be higher
            if eff_suit == lead_effective_suit and eff_rank > best_rank:
                best_player = player
                best_rank = eff_rank

    return best_player


def explain_euchre_trick_winner(
    trick_plays: Sequence[TrickPlay | Mapping[str, Any]],
    trump_suit: str,
) -> TrickWinnerExplanation:
    """Generates a human-friendly explanation of why a player won a completed trick."""
    if not trick_plays:
        raise ValueError("Cannot explain an empty trick")

    winner_email = evaluate_euchre_trick_winner(trick_plays, trump_suit)
    winning_play = next(
        p for p in trick_plays
        if (p.get("player") if isinstance(p, Mapping) else p.player) == winner_email
    )
    winning_card = Card.from_raw(winning_play["card"] if isinstance(winning_play, Mapping) else winning_play.card)

    clean_trump = str(trump_suit).strip().upper()
    eff_suit = get_euchre_effective_suit(winning_card, clean_trump)
    eff_rank = get_euchre_effective_rank(winning_card, clean_trump)

    if eff_suit == clean_trump:
        if eff_rank == RIGHT_BOWER_RANK:
            reason = "right_bower"
            expl = f"{winner_email} won with the Right Bower ({winning_card.label}{winning_card.suit_symbol}), the highest card in Euchre."
        elif eff_rank == LEFT_BOWER_RANK:
            reason = "left_bower"
            expl = f"{winner_email} won with the Left Bower ({winning_card.label}{winning_card.suit_symbol}), counting as the second-highest trump."
        else:
            reason = "high_trump"
            expl = f"{winner_email} won with high trump {winning_card.label}{winning_card.suit_symbol}."
    else:
        reason = "high_lead_suit"
        expl = f"{winner_email} won with high {winning_card.suit_name} ({winning_card.label}{winning_card.suit_symbol})."

    return TrickWinnerExplanation(
        winner=winner_email,
        winning_card=winning_card,
        reason_code=reason,
        explanation=expl,
    )


# =============================================================================
# Euchre Bot Decision Engine
# =============================================================================

def evaluate_euchre_hand_strength(
    hand: Sequence[Card | Mapping[str, Any]],
    candidate_trump: str,
) -> tuple[float, list[Card]]:
    """Evaluates the strength of a hand assuming candidate_trump is the trump suit.
    
    Returns:
        (score: float, trump_cards: list[Card])
    """
    clean_trump = str(candidate_trump).strip().upper()
    points = 0.0
    trumps: list[Card] = []
    suit_counts: dict[str, int] = {s: 0 for s in SUITS}

    for raw in hand:
        c = Card.from_raw(raw)
        eff_suit = get_euchre_effective_suit(c, clean_trump)
        eff_rank = get_euchre_effective_rank(c, clean_trump)
        suit_counts[eff_suit] = suit_counts.get(eff_suit, 0) + 1

        if eff_suit == clean_trump:
            trumps.append(c)
            if eff_rank == RIGHT_BOWER_RANK:
                points += 3.2
            elif eff_rank == LEFT_BOWER_RANK:
                points += 2.6
            elif eff_rank == 14:  # Ace
                points += 2.0
            elif eff_rank == 13:  # King
                points += 1.5
            elif eff_rank == 12:  # Queen
                points += 1.1
            elif eff_rank == 10:
                points += 0.7
            elif eff_rank == 9:
                points += 0.5
            elif eff_rank in (7, 8):
                points += 0.35
        else:
            # Off-suit cards
            if eff_rank == 14:  # Off-suit Ace is a boss trick winner
                points += 1.6
            elif eff_rank == 13:
                points += 0.4
            elif eff_rank == 12:
                points += 0.2

    # Bonus for 2-suit or void distribution (easier to ruff)
    non_trump_suits = [s for s in SUITS if s != clean_trump]
    voids = sum(1 for s in non_trump_suits if suit_counts[s] == 0)
    points += voids * 0.8

    return points, trumps


def decide_euchre_round1_action(
    hand: Sequence[Card | Mapping[str, Any]],
    upcard: Card | Mapping[str, Any],
    is_dealer: bool = False,
    is_dealer_partner: bool = False,
    profile: str = "medium",
) -> dict[str, Any]:
    """Determines whether an NPC bot orders up / picks up the upcard in bidding round 1.
    
    Returns:
        {"action": "pick_up" | "order_up" | "pass", "go_alone": bool}
    """
    up_card_obj = Card.from_raw(upcard)
    trump_suit = up_card_obj.suit
    base_points, trumps = evaluate_euchre_hand_strength(hand, trump_suit)

    # Dealer gets to add the upcard to their hand (huge value!)
    if is_dealer:
        base_points += 1.5
    elif is_dealer_partner:
        # Partner ordering up gives the upcard to the dealer!
        base_points += 0.8

    # Thresholds based on profile
    p_lower = str(profile).strip().lower()
    if p_lower == "hard":
        order_threshold = 4.2
        loner_threshold = 8.8
    elif p_lower == "easy":
        order_threshold = 5.0
        loner_threshold = 9.5
    else:  # medium
        order_threshold = 4.5
        loner_threshold = 9.0

    action = "pass"
    go_alone = False

    if base_points >= order_threshold:
        action = "pick_up" if is_dealer else "order_up"
        if base_points >= loner_threshold and len(trumps) >= 3:
            go_alone = True

    return {
        "action": action,
        "go_alone": go_alone,
        "points": round(base_points, 1),
    }


def decide_euchre_dealer_discard(
    hand: Sequence[Card | Mapping[str, Any]],
    upcard: Card | Mapping[str, Any],
    profile: str = "medium",
) -> Card:
    """Chooses which card the dealer should discard after picking up the upcard.
    
    Receives the 5 hand cards and the upcard (6 cards total).
    Returns the Card object to discard so the hand returns to 5 cards.
    """
    clean_trump = str(upcard.get("suit") if isinstance(upcard, Mapping) else upcard.suit).strip().upper()
    all_six: list[Card] = [Card.from_raw(c) for c in hand]
    up_obj = Card.from_raw(upcard)
    if not any(c.id == up_obj.id for c in all_six):
        all_six.append(up_obj)

    # Count suits to identify singletons to create voids!
    suit_counts: dict[str, int] = {s: 0 for s in SUITS}
    for c in all_six:
        eff_suit = get_euchre_effective_suit(c, clean_trump)
        suit_counts[eff_suit] = suit_counts.get(eff_suit, 0) + 1

    # Score each card for discard desirability (higher = better to discard)
    best_card = all_six[0]
    best_discard_score = -999.0

    for c in all_six:
        eff_suit = get_euchre_effective_suit(c, clean_trump)
        eff_rank = get_euchre_effective_rank(c, clean_trump)

        # Strongly protect trump cards
        if eff_suit == clean_trump:
            discard_score = -100.0 + (16 - eff_rank)
        else:
            # Off-suit: protect Aces
            if eff_rank == 14:
                discard_score = 0.0
            elif eff_rank == 13:
                discard_score = 10.0
            elif eff_rank == 12:
                discard_score = 15.0
            elif eff_rank == 11:
                discard_score = 20.0
            elif eff_rank == 10:
                discard_score = 25.0
            else:  # 9
                discard_score = 30.0

            # Bonus for discarding a singleton to create a VOID for ruffing!
            if suit_counts[eff_suit] == 1:
                discard_score += 20.0
            elif suit_counts[eff_suit] == 2:
                discard_score += 8.0

        if discard_score > best_discard_score:
            best_discard_score = discard_score
            best_card = c

    return best_card


def decide_euchre_round2_action(
    hand: Sequence[Card | Mapping[str, Any]],
    turned_down_suit: str,
    is_dealer: bool = False,
    is_eldest_hand: bool = False,
    stick_the_dealer: bool = True,
    profile: str = "medium",
) -> dict[str, Any]:
    """Determines whether an NPC bot calls trump in bidding round 2.
    
    Returns:
        {"action": "call" | "pass", "suit": str | None, "go_alone": bool}
    """
    clean_turned_down = str(turned_down_suit).strip().upper()
    candidate_suits = [s for s in SUITS if s != clean_turned_down]

    best_suit = candidate_suits[0]
    best_points = -1.0
    best_trumps: list[Card] = []

    for s in candidate_suits:
        pts, trumps = evaluate_euchre_hand_strength(hand, s)
        # Strategic "Next" bonus: Eldest hand calling the same color as the turned-down suit
        if is_eldest_hand and s == SAME_COLOR_SUIT.get(clean_turned_down):
            pts += 0.8
        if pts > best_points:
            best_points = pts
            best_suit = s
            best_trumps = trumps

    p_lower = str(profile).strip().lower()
    if p_lower == "hard":
        call_threshold = 4.0
        loner_threshold = 8.5
    elif p_lower == "easy":
        call_threshold = 4.8
        loner_threshold = 9.2
    else:  # medium
        call_threshold = 4.3
        loner_threshold = 8.8

    if best_points >= call_threshold:
        return {
            "action": "call",
            "suit": best_suit,
            "go_alone": (best_points >= loner_threshold and len(best_trumps) >= 3),
            "points": round(best_points, 1),
        }

    # If dealer and stick-the-dealer rule is ON: must call!
    if is_dealer and stick_the_dealer:
        return {
            "action": "call",
            "suit": best_suit,
            "go_alone": False,
            "points": round(best_points, 1),
            "forced": True,
        }

    return {"action": "pass", "suit": None, "go_alone": False, "points": round(best_points, 1)}


def decide_euchre_play(
    hand: Sequence[Card | Mapping[str, Any]],
    trick_plays: Sequence[TrickPlay | Mapping[str, Any]],
    trump_suit: str,
    partner_player: str | None = None,
    profile: str = "medium",
) -> Card:
    """Chooses the best legal card for an NPC bot to play in a trick."""
    clean_trump = str(trump_suit).strip().upper()
    lead_card = None
    if trick_plays:
        first = trick_plays[0]
        lead_card = first["card"] if isinstance(first, Mapping) else first.card

    legal_plays = get_legal_euchre_plays(hand, lead_card, clean_trump)
    if not legal_plays:
        # Fallback (should not happen if hand not empty)
        return Card.from_raw(hand[0])

    if len(legal_plays) == 1:
        return legal_plays[0]

    # If leading the trick
    if not trick_plays:
        # 1. Lead boss Right Bower if we have it
        right_bower = next((c for c in legal_plays if is_right_bower(c, clean_trump)), None)
        if right_bower:
            return right_bower
        # 2. Lead off-suit Ace
        off_aces = [
            c for c in legal_plays
            if get_euchre_effective_suit(c, clean_trump) != clean_trump and c.rank == 14
        ]
        if off_aces:
            return off_aces[0]
        # 3. Lead trump or low off-suit
        return legal_plays[0]

    # Playing to existing trick: see who is currently winning
    current_winner = evaluate_euchre_trick_winner(trick_plays, clean_trump)
    is_partner_winning = (partner_player is not None and current_winner == partner_player)

    if is_partner_winning:
        # Partner is currently winning: sluff lowest non-trump card or lowest card
        non_trumps = [
            c for c in legal_plays
            if get_euchre_effective_suit(c, clean_trump) != clean_trump
        ]
        if non_trumps:
            # Sort ascending rank
            non_trumps.sort(key=lambda c: get_euchre_effective_rank(c, clean_trump))
            return non_trumps[0]
        # Lowest trump
        legal_plays.sort(key=lambda c: get_euchre_effective_rank(c, clean_trump))
        return legal_plays[0]

    # Opponent is winning: try to take trick with lowest winning legal card
    winning_options: list[Card] = []
    for cand in legal_plays:
        sim_plays = list(trick_plays) + [{"player": "npc_sim", "card": cand}]
        if evaluate_euchre_trick_winner(sim_plays, clean_trump) == "npc_sim":
            winning_options.append(cand)

    if winning_options:
        # Choose the lowest winning card to conserve high power
        winning_options.sort(key=lambda c: get_euchre_effective_rank(c, clean_trump))
        return winning_options[0]

    # Cannot win: dump lowest useless card
    legal_plays.sort(key=lambda c: get_euchre_effective_rank(c, clean_trump))
    return legal_plays[0]

