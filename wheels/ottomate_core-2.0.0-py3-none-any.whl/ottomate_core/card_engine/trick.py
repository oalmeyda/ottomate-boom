"""Trick-taking follow-suit validation, winner evaluation, and human explanations."""

from __future__ import annotations
from typing import Any, Mapping, Sequence

from pydantic import Field, model_validator

from ottomate_core.card_engine.cards import Card
from ottomate_core.models import DictCompatibleModel


class TrickPlay(DictCompatibleModel):
    """Represents a single card played by a player into a trick."""

    player: str
    player_email: str = ""
    card: Card

    @model_validator(mode="before")
    @classmethod
    def _normalize_fields(cls, values: Any) -> Any:
        if isinstance(values, Mapping):
            data = dict(values)
            player = data.get("player") or data.get("player_email") or ""
            data["player"] = player
            data["player_email"] = data.get("player_email") or player
            if "card" in data and not isinstance(data["card"], Card):
                data["card"] = Card.from_raw(data["card"])
            return data
        return values


class CompletedTrick(DictCompatibleModel):
    """Represents a completed trick stored in round history."""

    leader: str | None = None
    winner: str
    winning_card: Card | None = None
    explanation: str | None = None
    cards: list[TrickPlay] = Field(default_factory=list)


class TrickWinnerExplanation(DictCompatibleModel):
    """Structured explanation of why a player won a completed trick."""

    winner: str
    winning_card: Card
    reason_code: str
    explanation: str


def is_legal_card_play(
    hand: Sequence[Card | Mapping[str, Any]],
    card_to_play: Card | Mapping[str, Any],
    lead_card: Card | Mapping[str, Any] | None = None,
) -> bool:
    """Validates the standard trick-taking 'follow suit' rule.

    1. The card must exist in the player's current hand.
    2. If no lead card has been played in this trick, any card in hand is legal.
    3. If a lead card exists, the player MUST play a card of that suit if they have one.
    4. If the player is void in the lead suit, they may play any card (trump or discard).
    """
    target_id = card_to_play["id"]
    if not any(c["id"] == target_id for c in hand):
        return False
    if lead_card is None:
        return True
    lead_suit = lead_card["suit"]
    has_lead_suit = any(c["suit"] == lead_suit for c in hand)
    if has_lead_suit:
        return card_to_play["suit"] == lead_suit
    return True


def get_legal_plays(
    hand: Sequence[Card | Mapping[str, Any]],
    lead_card: Card | Mapping[str, Any] | None = None,
) -> list[Card]:
    """Returns all cards in hand that are legal to play given the current lead card."""
    return [Card.from_raw(c) for c in hand if is_legal_card_play(hand, c, lead_card)]


def evaluate_trick_winner(
    trick: Sequence[TrickPlay | Mapping[str, Any]],
    trump_suit: str,
) -> str:
    """Evaluates the winner of a completed trick.

    Each item in trick is a TrickPlay or dict: {'player': email, 'card': card}.
    Rules:
    1. If any trump card was played, the highest rank trump card wins.
    2. If no trump card was played, the highest rank card of the led suit wins.
    """
    if not trick:
        raise ValueError("Cannot evaluate empty trick")
    lead_suit = trick[0]["card"]["suit"]
    trump_plays = [t for t in trick if t["card"]["suit"] == trump_suit]
    if trump_plays:
        return max(trump_plays, key=lambda t: t["card"]["rank"])["player"]
    lead_plays = [t for t in trick if t["card"]["suit"] == lead_suit]
    return max(lead_plays, key=lambda t: t["card"]["rank"])["player"]


def explain_trick_winner(
    trick: Sequence[TrickPlay | Mapping[str, Any]],
    trump_suit: str,
) -> TrickWinnerExplanation:
    """Explains why the winner won the completed trick in educational, human terms."""
    if not trick:
        raise ValueError("Cannot explain empty trick")

    lead_card = Card.from_raw(trick[0]["card"])
    lead_suit = lead_card.suit
    lead_suit_symbol = lead_card.suit_symbol or lead_suit
    lead_suit_name = lead_card.suit_name or lead_suit

    trump_plays = [t for t in trick if t["card"]["suit"] == trump_suit]

    if trump_plays:
        winning_play = max(trump_plays, key=lambda t: t["card"]["rank"])
        winner = winning_play["player"]
        winning_card = Card.from_raw(winning_play["card"])
        w_rank = winning_card.label or str(winning_card.rank)
        w_sym = winning_card.suit_symbol or trump_suit

        if lead_suit == trump_suit:
            reason_code = "highest_trump"
            explanation = f"Played the highest Trump ({w_rank}{w_sym}) on a Trump-led trick."
        elif len(trump_plays) == 1:
            reason_code = "trump_cut"
            explanation = f"Cut with Trump ({w_rank}{w_sym})! Trump beats the led {lead_suit_symbol} {lead_suit_name}."
        else:
            reason_code = "highest_trump"
            other_trumps = [
                f"{t['card'].get('label', str(t['card']['rank']))}{t['card'].get('suit_symbol', trump_suit)}"
                for t in trump_plays if t["player"] != winner
            ]
            others_str = ", ".join(other_trumps)
            explanation = f"Played the highest Trump ({w_rank}{w_sym}), beating {others_str}."
    else:
        lead_plays = [t for t in trick if t["card"]["suit"] == lead_suit]
        winning_play = max(lead_plays, key=lambda t: t["card"]["rank"])
        winner = winning_play["player"]
        winning_card = Card.from_raw(winning_play["card"])
        w_rank = winning_card.label or str(winning_card.rank)
        w_sym = winning_card.suit_symbol or lead_suit
        reason_code = "highest_lead_suit"

        off_suit_count = len(trick) - len(lead_plays)
        if off_suit_count > 0:
            explanation = (
                f"Played the highest card ({w_rank}{w_sym}) in the led {lead_suit_symbol} {lead_suit_name} suit. "
                "Off-suit discards cannot win without trump."
            )
        else:
            explanation = f"Played the highest card ({w_rank}{w_sym}) in the led {lead_suit_symbol} {lead_suit_name} suit."

    return TrickWinnerExplanation(
        winner=winner,
        winning_card=winning_card,
        reason_code=reason_code,
        explanation=explanation,
    )


def get_trick_turn_player(players: Sequence[str], trick_lead_player: str, current_trick_len: int) -> str:
    """Determines whose turn it is to play in the active trick based on clockwise seating."""
    lead_idx = list(players).index(trick_lead_player)
    return players[(lead_idx + current_trick_len) % len(players)]
