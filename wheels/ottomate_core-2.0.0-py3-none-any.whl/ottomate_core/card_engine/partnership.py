"""Partnership and 4-player compass seating engine for trick-taking card games."""

from __future__ import annotations
import re
from typing import Iterable, Literal

from ottomate_core.models import DictCompatibleModel

CompassSeat = Literal[0, 1, 2, 3]

SEATS: tuple[int, ...] = (0, 1, 2, 3)
SEAT_NAMES: dict[int, str] = {0: "South", 1: "West", 2: "North", 3: "East"}
TEAM_BY_SEAT: dict[int, int] = {0: 1, 1: 2, 2: 1, 3: 2}
PARTNER_BY_SEAT: dict[int, int] = {0: 2, 1: 3, 2: 0, 3: 1}


def get_team_for_seat(seat: int) -> int:
    """Returns the team (1 or 2) for a given compass seat (0-3)."""
    return TEAM_BY_SEAT[seat % 4]


def get_partner_seat(seat: int) -> int:
    """Returns the partner's compass seat (0 <-> 2, 1 <-> 3)."""
    return PARTNER_BY_SEAT[seat % 4]


def get_next_active_seat(
    current_seat: int,
    benched_seats: int | Iterable[int] | None = None,
    benched_seat: int | None = None,
) -> int:
    """Calculates clockwise next seat (0 -> 1 -> 2 -> 3 -> 0), skipping any benched players."""
    benched: set[int] = set()
    if benched_seat is not None:
        benched.add(benched_seat)
    if benched_seats is not None:
        if isinstance(benched_seats, int):
            benched.add(benched_seats)
        else:
            benched.update(benched_seats)

    nxt = (current_seat + 1) % 4
    attempts = 0
    while nxt in benched and attempts < 4:
        nxt = (nxt + 1) % 4
        attempts += 1
    return nxt


def get_compass_seating_arrangement(viewer_seat: int) -> dict[str, int]:
    """Rotates table compass positions so the viewer's seat is always South (bottom).
    
    Returns:
        dict with keys 'south', 'west', 'north', 'east' mapped to seat numbers 0-3.
    """
    s = viewer_seat % 4
    return {
        "south": s,
        "west": (s + 1) % 4,
        "north": (s + 2) % 4,
        "east": (s + 3) % 4,
    }


class PlayerSeatInfo(DictCompatibleModel):
    """Strongly-typed player seat representation in a 4-player partnership game."""

    user_id: str
    name: str
    seat: int
    team: int
    is_bot: bool = False
    bot_profile: str | None = None

    def clean_name(self) -> str:
        """Strips bot profile suffixes like '(medium)' or '(easy)' for clean UI display."""
        if not self.name:
            return ""
        return re.sub(r"\s*\((easy|medium|hard|npc)\)", "", self.name, flags=re.IGNORECASE).strip()


# Alias for backward compatibility with downstream game models
PlayerInfo = PlayerSeatInfo
