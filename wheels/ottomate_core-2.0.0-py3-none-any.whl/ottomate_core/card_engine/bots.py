"""Server-side NPC bot profiles, bid estimation, and trick play heuristics."""

from dataclasses import dataclass
from enum import Enum
import random

from ottomate_core.card_engine.trick import evaluate_trick_winner, get_legal_plays


class BotDifficulty(str, Enum):
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


NPC_PROFILES: list[str] = ["easy", "medium", "hard"]


@dataclass(frozen=True)
class BotProfile:
    name: str
    difficulty: BotDifficulty
    thinking_delay_ms: int = 1500


EASY_BOT = BotProfile("Easy Bot", BotDifficulty.EASY, 1000)
MEDIUM_BOT = BotProfile("Medium Bot", BotDifficulty.MEDIUM, 1500)
HARD_BOT = BotProfile("Hard Bot", BotDifficulty.HARD, 2000)


def decide_npc_bid(
    hand: list[dict],
    trump_card: dict,
    cards_for_round: int,
    profile: str = "easy",
    seed: int | str | None = None,
) -> int:
    """Decides a trick prediction bid for an automated NPC player.

    Profiles:
    - 'easy': Selects a random integer between 0 and cards_for_round.
    - 'medium': Rules-based estimation:
        - Trump card with rank >= 10 (10, J, Q, K, A) counts as +1 expected trick.
        - Non-trump card with rank >= 12 (Queen, King, Ace) counts as +1 expected trick.
        - Clamped to [0, cards_for_round].
    - 'hard': Aliases medium rules with tactical baseline.
    """
    clean_profile = (profile or "easy").strip().lower()
    if clean_profile == "easy":
        rng = random.Random(seed) if seed is not None else random.Random()
        return rng.randint(0, cards_for_round)

    trump_suit = trump_card["suit"]
    bid = 0
    for card in hand:
        rank = card["rank"]
        suit = card["suit"]
        if suit == trump_suit and rank >= 10:
            bid += 1
        elif suit != trump_suit and rank >= 12:
            bid += 1

    return max(0, min(bid, cards_for_round))


def decide_npc_play(
    hand: list[dict],
    current_trick: list[dict],
    trump_suit: str,
    bid: int,
    tricks_won: int,
    profile: str = "easy",
    seed: int | str | None = None,
) -> dict:
    """Decides which legal card an NPC player plays from their hand.

    Profiles:
    - 'easy': Randomly plays any legal card adhering to follow-suit rules.
    - 'medium': Objective-aware strategy:
        - Calculates needed = bid - tricks_won.
        - If needed > 0 (trying to win trick):
            - If leading: plays highest card (trumps/aces first).
            - If following: plays the highest legal card that beats current winning card.
              If unable to beat the winning card, plays the lowest legal card.
        - If needed <= 0 (trying to duck / avoid taking tricks):
            - Plays lowest legal card to minimize risk of taking accidental tricks.
    - 'hard': Aliases medium rules with tactical baseline.
    """
    lead_card = current_trick[0]["card"] if current_trick else None
    legal_cards = get_legal_plays(hand, lead_card)
    if not legal_cards:
        legal_cards = list(hand)

    clean_profile = (profile or "easy").strip().lower()
    if clean_profile == "easy":
        rng = random.Random(seed) if seed is not None else random.Random()
        return rng.choice(legal_cards)

    needed = bid - tricks_won

    def card_power(c: dict) -> int:
        if c["suit"] == trump_suit:
            return 100 + c["rank"]
        if lead_card and c["suit"] == lead_card["suit"]:
            return 20 + c["rank"]
        return c["rank"]

    if needed > 0:
        if not current_trick:
            return max(legal_cards, key=card_power)
        current_winner = evaluate_trick_winner(current_trick, trump_suit)
        winning_play = next(t for t in current_trick if t["player"] == current_winner)
        winning_power = card_power(winning_play["card"])

        beating_cards = [c for c in legal_cards if card_power(c) > winning_power]
        if beating_cards:
            return max(beating_cards, key=card_power)
        return min(legal_cards, key=card_power)

    return min(legal_cards, key=card_power)


# Convenience aliases
estimate_bot_bid = decide_npc_bid
choose_bot_card = decide_npc_play
