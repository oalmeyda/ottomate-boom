"""Platform-wide statistics, partnership chemistry, win streaks, and leaderboard rankers."""

from __future__ import annotations
from typing import Any, Mapping, Sequence

SCOPE_ALL = "all"
SCOPE_HUMAN_ONLY = "human_only"
SCOPE_WITH_BOTS = "with_bots"
SUPPORTED_STAT_SCOPES = (SCOPE_ALL, SCOPE_HUMAN_ONLY, SCOPE_WITH_BOTS)


def get_pair_key(p1_id: str, p2_id: str) -> str:
    """Returns a deterministic unique key for a pair of players regardless of order.
    
    Example:
        get_pair_key("Bob@example.com", "alice@example.com") -> "alice@example.com--bob@example.com"
    """
    ids = sorted([str(p1_id).strip().lower(), str(p2_id).strip().lower()])
    return f"{ids[0]}--{ids[1]}"


def calculate_win_rate(wins: int, total_games: int, decimals: int = 1) -> float:
    """Calculates win percentage with division-by-zero protection."""
    if total_games <= 0:
        return 0.0
    return round((wins / total_games) * 100, decimals)


def calculate_point_differential(points_scored: int, points_conceded: int) -> int:
    """Calculates net scoring margin."""
    return int(points_scored) - int(points_conceded)


class StreakTracker:
    """Calculates running current streaks and peak historical win streaks."""

    @staticmethod
    def compute_streak(
        outcomes: Sequence[bool],
        win_label: str = "W",
        loss_label: str = "L",
        none_label: str = "none",
    ) -> dict[str, Any]:
        """Calculates current streak from chronological outcome booleans (earliest -> latest)."""
        if not outcomes:
            return {"count": 0, "type": none_label}

        last = outcomes[-1]
        count = 0
        for val in reversed(outcomes):
            if val == last:
                count += 1
            else:
                break
        return {
            "count": count,
            "type": win_label if last else loss_label,
        }

    @staticmethod
    def compute_best_win_streak(outcomes: Sequence[bool]) -> int:
        """Finds the longest contiguous sequence of True values."""
        best = 0
        current = 0
        for won in outcomes:
            if won:
                current += 1
                best = max(best, current)
            else:
                current = 0
        return best

    @staticmethod
    def compute_date_streaks(
        won_dates: Sequence[str] | Any,
        reference_date: str | None = None,
    ) -> dict[str, int]:
        """Computes calendar-day `current_streak` and `max_streak` from ISO `YYYY-MM-DD` win dates.

        - Consecutive calendar days (`(d[i] - d[i - 1]).days == 1`) extend a streak.
        - `current_streak` remains active if the latest win was on `reference_date` (today UTC)
          or `reference_date - 1 day` (yesterday UTC); older wins reset `current_streak` to `0`.
        """
        from datetime import date as _date, datetime as _dt, timedelta as _td, timezone as _tz

        parsed_set: set[_date] = set()
        for raw in won_dates or ():
            if not raw:
                continue
            try:
                parsed_set.add(_date.fromisoformat(str(raw).strip()[:10]))
            except ValueError:
                continue

        if not parsed_set:
            return {"current_streak": 0, "max_streak": 0}

        ref_day: _date
        if reference_date:
            try:
                ref_day = _date.fromisoformat(str(reference_date).strip()[:10])
            except ValueError:
                ref_day = _dt.now(_tz.utc).date()
        else:
            ref_day = _dt.now(_tz.utc).date()

        # Filter out any future dates beyond ref_day so streaks reflect completed history
        ordered = sorted(d for d in parsed_set if d <= ref_day)
        if not ordered:
            return {"current_streak": 0, "max_streak": 0}

        max_streak = 1
        run = 1
        for idx in range(1, len(ordered)):
            if (ordered[idx] - ordered[idx - 1]).days == 1:
                run += 1
                if run > max_streak:
                    max_streak = run
            else:
                run = 1

        # Current streak is `run` (the final contiguous run) iff ordered[-1] is today or yesterday
        if ordered[-1] >= (ref_day - _td(days=1)):
            current_streak = run
        else:
            current_streak = 0

        return {"current_streak": current_streak, "max_streak": max_streak}


def rank_tournament_scores(cumulative_scores: Mapping[str, int]) -> list[dict[str, Any]]:
    """Ranks players in a completed game using competition ranking with 5/3/2/1 standing points.
    
    Awards:
      - 1st Place: 5 placement points
      - 2nd Place: 3 placement points
      - 3rd Place: 2 placement points
      - 4th+ Place: 1 participation point for completing the game
    """
    if not cumulative_scores:
        return []

    sorted_players = sorted(cumulative_scores.items(), key=lambda item: int(item[1]), reverse=True)

    ranked: list[dict[str, Any]] = []
    current_rank = 1
    for i, (player, score_val) in enumerate(sorted_players):
        score = int(score_val)
        if i > 0 and score < int(sorted_players[i - 1][1]):
            current_rank = i + 1

        if current_rank == 1:
            placement_pts = 5
            participation_pts = 0
        elif current_rank == 2:
            placement_pts = 3
            participation_pts = 0
        elif current_rank == 3:
            placement_pts = 2
            participation_pts = 0
        else:
            placement_pts = 0
            participation_pts = 1

        ranked.append({
            "player": player,
            "score": score,
            "rank": current_rank,
            "placement_points": placement_pts,
            "participation_points": participation_pts,
            "standing_points": placement_pts + participation_pts,
        })

    return ranked

