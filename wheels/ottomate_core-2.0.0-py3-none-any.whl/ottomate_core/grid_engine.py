"""Ottomate Core Grid Engine Primitives.

Provides 2D coordinate parsing, formatting, neighbor calculation (Manhattan and Chebyshev),
and deterministic daily seed generation for grid and puzzle games across the platform
(e.g., Battleship, Boom, Lingo).
"""

from __future__ import annotations

import string
from pydantic import BaseModel, Field

from ottomate_core.daily import generate_deterministic_daily_seed

__all__ = [
    "ALPHABET",
    "GridCoordinate",
    "format_grid_coordinate",
    "generate_deterministic_daily_seed",
    "get_grid_neighbors",
    "parse_grid_coordinate",
]

ALPHABET = string.ascii_uppercase  # A-Z


def parse_grid_coordinate(
    coord: str,
    max_cols: int = 26,
    max_rows: int = 100,
) -> tuple[int, int]:
    """Parse standard alphanumeric coordinate string (e.g. 'A1', 'J10', 'b5') into (row, col) 0-indexed indices.

    Args:
        coord: Coordinate string (e.g., 'A1', 'J10').
        max_cols: Maximum number of columns allowed (default 26, 'A'..'Z').
        max_rows: Maximum number of rows allowed (default 100, 1..100).

    Returns:
        tuple[int, int]: (row_idx, col_idx), 0-indexed.

    Raises:
        ValueError: If coord format is invalid or out of bounds.
    """
    if not isinstance(coord, str):
        raise ValueError("Coordinate must be a string")
    trimmed = coord.strip().upper()
    if len(trimmed) < 2:
        raise ValueError(f"Invalid coordinate format: '{coord}'")

    col_char = trimmed[0]
    row_part = trimmed[1:]

    if col_char not in ALPHABET[:max_cols]:
        raise ValueError(
            f"Invalid column '{col_char}' in coordinate '{coord}'. "
            f"Must be between 'A' and '{ALPHABET[max_cols - 1]}'."
        )

    try:
        row_num = int(row_part)
    except ValueError as exc:
        raise ValueError(f"Invalid row number '{row_part}' in coordinate '{coord}'") from exc

    if row_num < 1 or row_num > max_rows:
        raise ValueError(f"Row number must be between 1 and {max_rows}, got {row_num}")

    row_idx = row_num - 1
    col_idx = ALPHABET.index(col_char)
    return row_idx, col_idx


def format_grid_coordinate(row: int, col: int, max_cols: int = 26, max_rows: int = 100) -> str:
    """Format (row, col) 0-indexed indices into standard coordinate string (e.g. (0, 0) -> 'A1', (9, 9) -> 'J10').

    Args:
        row: 0-indexed row index.
        col: 0-indexed column index.
        max_cols: Maximum number of columns allowed (default 26).
        max_rows: Maximum number of rows allowed (default 100).

    Returns:
        str: Alphanumeric coordinate string (e.g., 'A1').

    Raises:
        ValueError: If row or col are out of bounds.
    """
    if not (0 <= row < max_rows and 0 <= col < max_cols):
        raise ValueError(f"Coordinates out of bounds: row={row}, col={col} (bounds: {max_rows}x{max_cols})")
    return f"{ALPHABET[col]}{row + 1}"


def get_grid_neighbors(
    row: int,
    col: int,
    rows: int,
    cols: int,
    include_diagonals: bool = True,
) -> list[tuple[int, int]]:
    """Return adjacent coordinate tuples for (row, col) within bounded grid [0, rows) x [0, cols).

    Args:
        row: 0-indexed row index.
        col: 0-indexed column index.
        rows: Total number of rows in the grid.
        cols: Total number of columns in the grid.
        include_diagonals: If True, returns 8-directional neighbors (Chebyshev).
                           If False, returns 4-directional orthogonal neighbors (Manhattan).

    Returns:
        list[tuple[int, int]]: Valid neighbor coordinates within bounds.
    """
    delta_offsets = (
        ((-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1))
        if include_diagonals
        else ((-1, 0), (1, 0), (0, -1), (0, 1))
    )
    neighbors: list[tuple[int, int]] = []
    for dr, dc in delta_offsets:
        nr, nc = row + dr, col + dc
        if 0 <= nr < rows and 0 <= nc < cols:
            neighbors.append((nr, nc))
    return neighbors



class GridCoordinate(BaseModel):
    """Pydantic model representing a 2D grid position with algebraic conversions."""

    row: int = Field(ge=0, description="0-indexed row position")
    col: int = Field(ge=0, description="0-indexed column position")

    def to_algebraic(self, max_cols: int = 26, max_rows: int = 100) -> str:
        """Format to standard algebraic coordinate (e.g., 'A1')."""
        return format_grid_coordinate(self.row, self.col, max_cols=max_cols, max_rows=max_rows)

    @classmethod
    def from_algebraic(
        cls,
        coord: str,
        max_cols: int = 26,
        max_rows: int = 100,
    ) -> GridCoordinate:
        """Parse from standard algebraic coordinate (e.g., 'A1', 'J10')."""
        r, c = parse_grid_coordinate(coord, max_cols=max_cols, max_rows=max_rows)
        return cls(row=r, col=c)
