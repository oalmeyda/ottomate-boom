"""Daily puzzle and challenge seeding utilities."""

from __future__ import annotations

import hashlib


def generate_deterministic_daily_seed(
    service_id: str,
    date_str: str,
    salt: str = "",
    length: int = 16,
) -> str:
    """Derive a deterministic cryptographic hex seed string for a daily puzzle or challenge.

    Args:
        service_id: Identifier of the service (e.g. 'boom', 'lingo', 'solostaire').
        date_str: Date string in YYYY-MM-DD format.
        salt: Optional mode, difficulty, or category discriminator.
        length: Desired hex character length of the returned seed (default 16, max 64).

    Returns:
        str: Deterministic hexadecimal seed string.
    """
    raw = f"{service_id}:{date_str}:{salt}".encode("utf-8")
    full_hex = hashlib.sha256(raw).hexdigest()
    return full_hex[:length]
